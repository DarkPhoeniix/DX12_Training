#pragma once

struct SceneDesc
{
    row_major matrix    ViewProjection;
    row_major matrix    View;
    row_major matrix    Projection;
    
    row_major matrix    InvView;
    row_major matrix    InvProjection;
    
    float4              EyePosition;
    float4              EyeDirection;
    
    uint2               WindowSize;
    float2              ReciprocalWindowSize;
    float2              NearFar;
    
    uint                LightsNum;
    uint                LightsBufferIndex;
};

struct ModelDesc
{
    row_major matrix    Transform;
    
    uint                AlbedoTextureIndex;
    uint                NormalTextureIndex;
    uint                MetalnessTextureIndex;
    uint                RoughnessTextureIndex;
    
    uint                HasMesh;
    uint                BonesBufferIndex;
    uint                pad[2];
};

////////////////////////////////////////////////////////////////////////////////

//ConstantBuffer<SceneDesc> Scene : register(b0);
//ConstantBuffer<ModelDesc> Model : register(b1);
