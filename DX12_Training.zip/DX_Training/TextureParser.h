#pragma once
class TextureParser
{
};

