#pragma once

class Event
{
public:
    Event()
    {   }
};
