//#pragma once
//
//#include <fbxsdk.h>
//
//class Scene
//{
//public:
//    Scene();
//    ~Scene();
//
//    bool LoadScene(const std::string& name);
//
//private:
//    FbxManager* _FBXManager;
//    FbxScene* _scene;
//};
//
