#pragma once

class IObject
{
public:
    ~IObject();



private:

};
