#include "stdafx.h"

#include "IObject.h"

IObject::~IObject()
{

}
